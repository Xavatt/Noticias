export const environment = {
  production: true,
  apyKey: '1ee65e0be9694447a9f12b301e8789c1'
};
